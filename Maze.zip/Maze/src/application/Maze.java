package application;

public class Maze {

}
