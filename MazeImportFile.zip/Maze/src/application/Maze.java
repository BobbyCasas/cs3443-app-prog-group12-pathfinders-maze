package application;

/****************************************************************************************************
 * @author 
 * UTSA CS 3443 - Group project - Pathfinders - Maze
 * Fall 2021
 * 
 * Maze is a constructor class which loads, stores, and tracks a Maze object.
 * 
 * Variables:
 * 		Example ex	- This is an example variable for comments
 ***************************************************************************************************/
public class Maze {
	
	public Maze() {
		
	}
}